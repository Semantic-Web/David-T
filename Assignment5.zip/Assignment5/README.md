Assignment 5 Description

Two options: 
---------------------------------------------------------------------------------------------------------
Option 2 assumes that you have good Java background; Option 1 assumes that you do not have good Java background.


Option 1: 
---------
Use Foafamatic site to build a .rdf file of you and your friends. 
Use Protege to build an .owl file of a few more friends, with some of them same as the FOAF friends, 
but perhaps with variation in first names. Thus it may be Bob Clark and Robert Clark. 
Use SameAs in Java code to develop equivalency. 
Reason with both of them, and display results in a screen capture for your friends' group. 
Submit the project folder (as a zip folder) and zip it again with the screen capture and submit it as a double zipped folder

Option 2:
---------
Use your assignment 1's .owl file, import the instance data of activity log as a .csv file 
and use Jave routines to reason and add instance RDF data based on the .csv file added. 
Display some of the instance data in rdf format in the Eclipse window and capture that in a screen capture. 
Submit the project folder (as a zip folder) and zip it again with the screen capture and submit it as a double zipped folder.

Add sufficient comments in the code so it is useful to the reader. 
Submit it in a separate folder at your Github Repo entitled as "Assignment 5"
-------------------------------------------------------------------------------

File includes: 
- Zipped Project File "HelloSemanticWeb"
- Screenshots of code, output, FOAFFriends.rdf, and additionalFrieends.owl.

